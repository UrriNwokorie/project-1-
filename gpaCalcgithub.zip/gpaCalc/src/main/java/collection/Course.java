package collection;

public class Course {
    private String courseNo;
    private String grade;
    private String creditHours;
}
