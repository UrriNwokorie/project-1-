package collection;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
@Data
@Builder
@Document(collection = "Student")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Student {
    @Id
    private String studentID;
    private String firstName;
    private String email;
    private String gender;
    private List<Course> course;
}
