package com.gpaCalc.gpaCalc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpaCalcApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpaCalcApplication.class, args);
	}

}
