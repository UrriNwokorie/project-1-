package controller;

import collection.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import service.studentService;

@RestController
@RequestMapping("/student")
public class studentController {
    @Autowired

    private studentService studentService;

    @PostMapping
    public String save (@RequestBody Student student){

        return studentService.save(student);

    }

}
