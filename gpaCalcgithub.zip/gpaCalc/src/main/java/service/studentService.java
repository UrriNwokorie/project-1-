package service;

import collection.Student;

public interface studentService {
    String save(Student student);
}
