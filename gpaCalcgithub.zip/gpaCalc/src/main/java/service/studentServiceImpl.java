package service;

import collection.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.studentRepository;

@Service
public class studentServiceImpl implements studentService{
    @Autowired
    private studentRepository studentRepository;
    @Override
    public String save(Student student) {
        return studentRepository.save(student).getStudentID();
    }
}
