package com.gpaCalc.gpaCalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpaCalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
